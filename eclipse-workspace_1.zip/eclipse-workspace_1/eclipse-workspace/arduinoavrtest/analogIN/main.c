// Diese Beispiel zeigt die Anwendung des ADC eines ATmega169
// unter Verwendung der internen Referenzspannung von nominell 1,1V.
// Zur Anpassung an andere AVR und/oder andere Referenzspannungen
// siehe Erläuterungen in diesem Tutorial und im Datenblatt

#define F_CPU 16000000UL
#include <stdbool.h>
#include <stdint.h> 
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "i2clcd.h"
#include "i2cmaster.h"
#include "adc.h"


int main( void )
{
    uint16_t adcval;
    char string1[] = "Hello_World!!";

    ADC_Init();
	
    i2c_init();
	lcd_init();
    lcd_light(true);
	lcd_print(string1);
    lcd_command(LCD_DISPLAYON | LCD_CURSORON | LCD_BLINKINGON);
    _delay_ms(5000);
    
    while( 1 ) {
        adcval = ADC_Read(0);
        sprintf(string1, "%i", adcval);
        _delay_ms(200);
        lcd_command(LCD_CLEAR);
        _delay_ms(20);
        lcd_print(string1);
        
        
    }
}
