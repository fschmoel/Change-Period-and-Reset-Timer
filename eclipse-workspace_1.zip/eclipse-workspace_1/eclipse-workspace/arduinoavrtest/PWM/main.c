
#define F_CPU 16000000UL
#include <stdbool.h>
#include <stdint.h> 
#include <avr/pgmspace.h>
#include <util/delay.h>
#include <avr/io.h>
#include "pwm.h"

int i;

int main(void)
{
//Externer Quarz als Taktgeber verwenden
switch_clock_rc_to_extern();
//Clockdiv auf 0 stellen
set_clockdiv(0);
//JTAG deaktivieren
jtag_deaktivieren();
//PWM Ausgänge definieren
DDRB |= (1<<DDB7)|(1<<DDB6)|(1<<DDB5);
//Timer1 Initialisieren
timer1_init();
//50% PWM für LED0,LED1,LED2 einstellen
LED0 = 32768;
LED1 = 32768;
LED2 = 32768;
_delay_ms(2000);
    while(1)
    {
        for(i=0; i<1023; i=i+10){
            LED0 = i*64;
            LED1 = i*32;
            LED2 = i*16;
            _delay_ms(100);
        }

    }
}
