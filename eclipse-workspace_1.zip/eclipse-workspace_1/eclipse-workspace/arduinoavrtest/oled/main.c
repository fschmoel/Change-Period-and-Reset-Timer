/*!
 * @file main.c
 *
 *
 *
 */
// Default CPU Speed
#ifndef F_CPU
 #define F_CPU 16000000UL
#endif

#include <avr/io.h>
#include <util/delay.h>
#include <avr/pgmspace.h>
#include <stdlib.h>
#include <stdbool.h>

// Display Library from Michael Köhler =>fasterbetterharderstronger
#include "display/lcd.h"
#include "controller/controller_config.h"
#include "controller/controller.h"


int main(void) {
	lcd_init(LCD_DISP_ON);  //initialize display
	
  	lcd_clear_buffer();
	lcd_gotoxy(5,1);
	lcd_puts("Hallo Welt");
	lcd_gotoxy(1, 2);
	lcd_puts("Zeile 2");
	
	lcd_gotoxy(2, 3);
	lcd_puts("Zeile 3");
	
	lcd_gotoxy(3, 4);
	lcd_puts("Zeile 4");
	
	lcd_gotoxy(4, 5);
	lcd_puts("Zeile 5");
	
	lcd_gotoxy(5, 6);
	lcd_puts("Zeile 6");
	
	lcd_gotoxy(6, 7);
	lcd_puts("Zeile 7");
	lcd_display();
	while(1){
	
	}
	return 0;
}
