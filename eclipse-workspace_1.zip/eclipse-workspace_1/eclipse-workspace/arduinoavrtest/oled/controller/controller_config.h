/*!
 * @file controller_config.h
 *
 *  Created on: 31.03.2020
 *      Author: V.Weiss
 */
 /** \addtogroup <Periphery configuration>
  *  @{
  */
/*!
  @brief Controller types are set here, please change if neccessary
  @param J or E defines joystick or encoder type controller
*/
 #define CONTROLLER_1_TYPE 'J' //J joystick or E encoder
 #define CONTROLLER_2_TYPE 'E' //joystick or encoder

#if 'J' == CONTROLLER_1_TYPE
      #pragma message "Controller 1 for Oneplayer is Joystick Type"
#elif 'E' == CONTROLLER_1_TYPE
      #pragma message "Controller 1 for Oneplayer is Encoder Type"
#else
    #error "No valid configuration for CONTROLLER_1_TYPE, see controller_config.h"
#endif

#if 'J' == CONTROLLER_2_TYPE
  #pragma message "Controller 2 is Joystick Type"
#elif 'E' == CONTROLLER_2_TYPE
  #pragma message "Controller 2 is Encoder Type"
#else
 #error "No valid configuration for CONTROLLER_2_TYPE, see controller_config.h"
#endif
/*!
  @brief Port configuration
  @param Register Names , MCU type
  @note if other Pin and ports shall be used, configure here, please mind MCU abilities , Pin Notations in Arduino Nomenclature
*/
 #ifndef CONTROLLER_CONTROLLER_CONFIG_H_
  #if defined (__AVR_ATmega328P__)
   #define CONTROLLER_CONTROLLER_CONFIG_H_
   #define JSTICK_1_BUT PD2	/**< Pin D3 used for button 1*/
   #define JSTICK_2_BUT PD3	/**< Pin D2 used for button 2*/
   #define JSTICK_1_Y PC0		/**< Pin A0 used for Joystick 1 analog*/
   #define JSTICK_2_Y PC1		/**< Pin A2 used for Joystick 2 analog*/
   #define JSTICK_SWITCH_PORT PORTD
   #define JSTICK_SWITCH_REG  DDRD
   #define JSTICK_SWITCH_PINS PIND
   #define JSTICK_AD_PORT PORTC
   #define JSTICK_AD_REG DDRC
   // Encoders
   #define ENC_PORT PORTD
   #define ENC_PIN PIND
   #define ENC_DREG  DDRD

   #define ENC1_PINA PD4  /**<  Pin D4 used for Encoder 1 output A*/
   #define ENC1_PINB PD5  /**<  Pin D5 used for Encoder 1 output B*/
   #define ENC2_PINA PD6  /**<  Pin D6 used for Encoder 2 output A*/
   #define ENC2_PINB PD7  /**<  Pin D7 used for Endocer 2 output B*/
   #define REFERENCE _BV(REFS0)  /**<  Set AVcc as reference source, thus reference is 5V*/
   #define J1_MUX_SETTINGS REFERENCE  /**< Mux register set to 000 , connecting A0 to ADC*/
   #define J2_MUX_SETTINGS _BV(REFS0) | _BV(MUX0) /**<  Mux register set to 000 , connecting A1 to ADC*/

   // Sound Output Configuration
   #define SOUND_PORT PORTB
   #define SOUND_PIN  PB1
   #define SOUND_DREG DDRB

   #pragma message "Ports Configured for ATmega328p aka Arduino Micro"
  #else
    #if defined (__AVR_ATmega32U4__)
      #define CONTROLLER_CONTROLLER_CONFIG_H_
      #define JSTICK_1_BUT PF0	/**< Pin A5 used for button 1*/
      #define JSTICK_2_BUT PF1	/**< Pin A4 used for button 2*/
      #define JSTICK_1_Y PF7		/**< Pin A0 used for Joystick 1 analog*/
      #define JSTICK_2_Y PF5		/**< Pin A2 used for Joystick 2 analog*/
      #define JSTICK_SWITCH_PORT PORTF
      #define JSTICK_SWITCH_REG DDRF
      #define JSTICK_SWITCH_PINS PINF
      #define JSTICK_AD_PORT PORTF
      #define JSTICK_AD_REG DDRF
      //Encoders
      #define ENC_PORT PORTF
      #define ENC_PIN PINF
      #define ENC_DREG  DDRF

      #define ENC1_PINA PF7  /**< Pin A0 used for Encoder 1 output A*/
      #define ENC1_PINB PF6  /**< Pin A1 used for Encoder 1 output B*/
      #define ENC2_PINA PF5  /**< Pin A2 used for Encoder 2 output A*/
      #define ENC2_PINB PF4  /**< Pin A3 used for Encoder 2 output B*/
      #define REFERENCE _BV(REFS0) /**<  Set AVcc as reference source, thus reference is 5V*/
      #define J1_MUX_SETTINGS REFERENCE | _BV(MUX0)| _BV(MUX1) |_BV(MUX2)  /**< Mux register set to 111 , connecting A0 to ADC*/
      #define J2_MUX_SETTINGS REFERENCE | _BV(MUX0)| _BV(MUX2)            /**< Mux register set to 011 , connecting A1 to ADC*/

      // Sound Output Configuration
      #define SOUND_PORT PORTB
      #define SOUND_PIN  PB5
      #define SOUND_DREG DDRB

      #pragma message "Ports Configured for ATmega32u4 aka Arduino Nano"
    #else
     #error "No valid MCU defined"
    #endif
  #endif
  #define CONTROLLER_SWITCH_MASK _BV(JSTICK_1_BUT) | _BV(JSTICK_2_BUT);
  #define CONTROLLER_AD_MASK _BV(JSTICK_1_Y) | _BV(JSTICK_2_Y);
#endif /* CONTROLLER_CONTROLLER_CONFIG_H_ */
/** @}*/
