/*!
 * @file controller.c
 * @note #define switches CONTROLLER_1_TYPE and CONTROLLER_2_TYPE need to be set either to J (analog hoystick) or E (incremental 2 step encoder),
 *				depending on used controller type!
 *        Created on: 31.03.2020
*  @author  V.Weiß
 *
 *
 */
#include <avr/io.h>
#include <stdbool.h>
#include <avr/interrupt.h>

#include "controller.h"
#include "controller_config.h"

//Systick value
static uint16_t systick;
//timer values for tone generation
static uint8_t timer_ocr_nextvalue;
static uint16_t timer_length;

#if 'E' == CONTROLLER_1_TYPE
static int8_t lencoder_delta;
static int8_t llaststate;
#endif
#if 'E' == CONTROLLER_2_TYPE
 static int8_t rencoder_delta;
 static int8_t rlaststate;
#endif

/** \addtogroup <Button and Encoder Setup>
 *  @{
 */

/*!
  @brief Setup Port & Data direction registers for reading Buttons
  @param none
  @return none (void)
  @brief configuration/register names depends on MCU type, see contorller_config.h
*/
void setup_buttons(void){
  // controller digital pins (buttons)
  JSTICK_SWITCH_REG &= ~CONTROLLER_SWITCH_MASK;		// Inputs
  JSTICK_SWITCH_PORT |= CONTROLLER_SWITCH_MASK;		// Pullup
}
/*!
  @brief	checks if the ontroller button is pressed
  @param	button	checked button
  @return	true if button is pressed otherwise false
*/
bool ControllerPressed(uint8_t button) {
	if(!(JSTICK_SWITCH_PINS & _BV(button)))	// check if pin (button) is not high -> pressed
		return true;
	else
		return false;
}
/*END Button Setup*/

/*BEGIN Setup for Encoder type controllers */
#if 'E'==CONTROLLER_1_TYPE ||  'E' == CONTROLLER_2_TYPE
/*!
	@brief setups incremental encoders for controlling bats
	@return none (void)
	@note configuration/register names depends on MCU type, see contorller_config.h
*/
void EncoderSetup(void) {
#if 'E' == CONTROLLER_1_TYPE
	int8_t lnewstate = 0;
#endif
#if 'E' == CONTROLLER_2_TYPE
	int8_t rnewstate = 0;
#endif

	ENC_DREG &= ~(_BV(ENC1_PINA)| _BV(ENC1_PINB)| _BV(ENC2_PINA) | _BV(ENC2_PINB) );	//Set DDR to input
  ENC_PORT |= (_BV(ENC1_PINA) | _BV(ENC1_PINB) | _BV(ENC2_PINA) | _BV(ENC2_PINB) );	//Set Pullups, encoder ties to GND

	uint8_t pinbuffer = ENC_PIN;								// Read and save actual status
#if 'E' == CONTROLLER_1_TYPE
	if(pinbuffer & _BV(ENC1_PINA)) lnewstate = 3;
	if(pinbuffer & _BV(ENC1_PINB)) lnewstate ^= 1;
	lencoder_delta = 0;
	llaststate = lnewstate;
#endif
#if 'E' == CONTROLLER_2_TYPE
	if(pinbuffer & _BV(ENC2_PINA)) rnewstate = 3;
	if(pinbuffer & _BV(ENC2_PINB)) rnewstate ^= 1;
	rlaststate = rnewstate;
	rencoder_delta = 0;
#endif
 setup_timer0();
}
#if 'E' == CONTROLLER_1_TYPE
/*!
	@brief read, reset and return counted encoder steps
  @param None
  @return int8_t in gray code steps since last readout
	@note Encoder 1
*/
int8_t GetEncoderL(void){
	int8_t val;
		cli(); 												//Stop  Interrupts
	val = lencoder_delta;
  lencoder_delta = 0;
	sei(); 													// Enable Interrupts again
	return(val);
}
#endif
/*!
	@brief Read, reset and return counted encoder steps
  @param None
  @return int8_t in gray code steps since last readout
	@note Encoder 2
*/
#if 'E' == CONTROLLER_2_TYPE
int8_t GetEncoderR(void){
	int8_t val;
	cli(); 												//Stop  Interrupts
	val = rencoder_delta;
	rencoder_delta = 0;
	sei();												// Enable Interrupts again
	return(val);
}
#endif
#endif
/** @}*/

/** \addtogroup <Joystick and ADC setup>
 *  @{
 */
#if 'J' == CONTROLLER_1_TYPE || 'J' == CONTROLLER_2_TYPE
 /*!
   @brief	setups the adc and performce the first conversion
   @return 	None (void)
   @note  	REFS0	AVcc with external capacitor on AREF pin
 			MUX2:0	single ended input, depend on controller_config.h
 			ADEN	enable adc
 			ADSC	start conversion
 			ADPS2:0	adc prescaler here: divison factor 128 -> 125kHz
 */
 void AdcSetup(void) {
 	ADMUX = _BV(REFS0);	// changed from AD7 to AD0
 	ADCSRA = _BV(ADEN) | _BV(ADSC) | _BV(ADPS0) | _BV(ADPS1) | _BV(ADPS2);
  // configure ADC Pins without pullups
  JSTICK_AD_REG &= ~CONTROLLER_AD_MASK;		// Input
  JSTICK_AD_PORT &= ~CONTROLLER_AD_MASK;	// NO Pullups
 	while (ADCSRA & (1 << ADSC)) { // takes 25 ADC clock cycles instead of normal 13 (initialization of the ADC)
 		// wait until conversion is ready
 	}
 }
 #endif

#if 'J' == CONTROLLER_1_TYPE
/*!
  @brief	configure, starts and return the adc value of JSTICK_1
  @return	adc value (10bit)
  @note		REFS0	AVcc with external capacitor on AREF pin
			MUX2:0	single ended input
			ADSC	start conversion
*/
uint16_t GetAdcJSTICK_1(void) {
	ADMUX = 0b00000000;			// clear register
	ADMUX |= J1_MUX_SETTINGS;			// changed from ADC7 to AD0

	ADCSRA |= (1 << ADSC);		// start ADC

	while (ADCSRA & (1 << ADSC)) {
		// wait until conversion is ready
	}

	return ADC;
}
#endif

#if 'J' == CONTROLLER_2_TYPE
/*!
  @brief	configure, starts and return the adc value of JSTICK_2
  @return	adc value (10bit)
  @note		REFS0	AVcc with external capacitor on AREF pin
			MUX2:0	single ended input
			ADSC	start conversion
*/
uint16_t GetAdcJSTICK_2(void) {
	ADMUX = 0b00000000;			// clear register
	ADMUX |= J2_MUX_SETTINGS;	// changed from AD5 to AD1

	ADCSRA |= (1 << ADSC);		// start ADC

	while (ADCSRA & (1 << ADSC)) {
		// wait until conversion is ready
	}

	return ADC;
}
#endif
/** @}*/

/** \addtogroup <Timer0 Setup for Systick>
 *  @{
 */

/*!
  @brief  Setup Timer0 to trigger Encoder Readout
  @note   Timer is configured to 1kHz= 1ms Tick
*/
void setup_timer0(void){
  // Set Timer to 1ms Interval
  TCCR0A = _BV(WGM01);														//Timer0 in CTC Mode
  TCCR0B = _BV(CS01) | _BV(CS00);									//Prescaler 64
  OCR0A = (uint8_t)(F_CPU / 64.0 * 1e-3 - 0.5);		//Calculate to 1ms interval
  // Enable timer
  TIMSK0 |= _BV(OCIE0A);
  systick = 0;
  sei();
}
/*!
  @brief  gets module static systick and returns to calling function
  @param none
  @return uint16_t systick value
*/
uint16_t get_systick(void){
  uint16_t temp;
  temp = systick;
  return temp;
}

/*!
	@brief Timer0 interrupt for sampling encoder states, does also systicki();
	@note Both Encoders are read out at a time
*/
ISR( TIMER0_COMPA_vect ){            // 1ms for manual movement
  int8_t newstate, diff;
	uint8_t pinbuffer = ENC_PIN;
  // Read and save actual status for left encoder
  cli();
	#if 'E' == CONTROLLER_1_TYPE
	newstate = 0;
	if(pinbuffer & _BV(ENC1_PINA)) newstate = 3;
	if(pinbuffer & _BV(ENC1_PINB)) newstate ^= 1;
  diff = llaststate - newstate ;
  if( diff & 1 ) {                 // bit 0 = value (1)
    llaststate = newstate;                    // store new as next last
    lencoder_delta += (diff & 2) - 1;   // bit 1 = direction (+/-)
	}
	#endif
	#if 'E' == CONTROLLER_2_TYPE
	// Read and save actual status for right encoder
	newstate = 0;
	if(pinbuffer & _BV(ENC2_PINA)) newstate = 3;
	if(pinbuffer & _BV(ENC2_PINB)) newstate ^= 1;
	diff = rlaststate - newstate ;
	if( diff & 1 ) {                 // bit 0 = value (1)
		rlaststate = newstate;                    // store new as next last
		rencoder_delta += (diff & 2) - 1;   // bit 1 = direction (+/-)
	}
	#endif
  if(timer_length) timer_length--;
  systick++;
  sei();
 }
/** @}*/

/** \addtogroup <Sound functions>
 *  @{
 */
/*This part may moved to an external library later*/
/*Timer1 is used for playing Sounds*/
static uint8_t timer_ocr_nextvalue;
static uint16_t timer_length;
/*!
  @brief  initializes Timer1 for Sound output
  @param  none
  @return none
  @note   Timer 1 is used in CTC mode with Output compare on OCR1A, Connect speaker to PINB1 , D9 on Arduino nano
*/
void setup_sound(void){
  SOUND_PORT &= ~_BV(SOUND_PIN);                   //Set value to 0
  SOUND_DREG  |= _BV(SOUND_PIN);                    //Set Pin direction to output
  TCCR1A = 0;                           //reset timer1 control register A
  TCCR1B = 0;                           //reset timer1 control register B
  //OCR1AL = 0;                         //reset counter register to 0
  TCCR1B |= _BV(CS12)|_BV(WGM12);       //CTC with OC1A top mode, Prescaler = 1/256
  TIMSK1 |= _BV(OCIE1A);                //enable output compare A match interrupt
}

/*!
  @brief  plays a tone
  @param  uint8_t tone (OCR1A value) , uint16_length (1ms steps)
  @return none
  note    This function sets buffer values for timer1 to be played as tone, length is decreased during timer0 interrupt
*/
void play_sound(uint8_t tone, uint16_t length){
  if(tone){
    if(tone != timer_ocr_nextvalue){
      timer_ocr_nextvalue = tone;
    }
    TCCR1A |= _BV(COM1A0);            //enable pin toggling, thus output sound
    timer_length = length;
    }
  else{
    TCCR1A &= ~(_BV(COM1A0));         //disable pin toggling, silence
  }
}
/*!
  @brief  Timer1 interrupt routine
  @param  uint8_t timer_ocr_nextvalue (static, defined in module)
  @return none
  @note  Interrupt routine takes care of updating Timer1 CTC values, resulting in frequencies, and routing Timer CTC event to speaker PIN
*/
ISR( TIMER1_COMPA_vect){
  unsigned char sreg;
  // buffering interrupt register to ensure atomic 2x byte write
  sreg = SREG;
  cli();
  OCR1AH =0;
  OCR1AL = timer_ocr_nextvalue;
  if(timer_length && (TCCR1A && _BV(COM1A0))){
    ;;                            // Everything is fine, don't touch it
  }
  else{
    TCCR1A &= ~(_BV(COM1A0));     // Mute Sound
  }
  // restore interrupt status, thus enabling interrupts again
  SREG = sreg;
}

/*!
 @brief   Play some game melody
 @note    note freq and duration are set here in play_sound calls directly
*/

void play_melody(void){
  play_sound(148,100);
  while((TCCR1A && _BV(COM1A0))){
    ;;
  }
  for(int i=1; i<=1; i++){
    play_sound(132,20);
    while((TCCR1A && _BV(COM1A0))){
      ;;
    }
    play_sound(111,20);
    while((TCCR1A && _BV(COM1A0))){
      ;;
    }
    play_sound(88,20);
    while((TCCR1A && _BV(COM1A0))){
        ;;
    }
  }
  play_sound(148,100);
  while((TCCR1A && _BV(COM1A0))){
    ;;
  }
  for(int i=1; i<=1; i++){
    play_sound(99,20);
    while((TCCR1A && _BV(COM1A0))){
      ;;
    }
    play_sound(88,20);
    while((TCCR1A && _BV(COM1A0))){
      ;;
    }
    play_sound(44,20);
    while((TCCR1A && _BV(COM1A0))){
      ;;
    }
 }
  play_sound(148,100);
  while((TCCR1A && _BV(COM1A0))){
    ;;
  }
  for(int i=1;i<=1;i++){
   play_sound(132,20);
   while((TCCR1A && _BV(COM1A0))){
     ;;
   }
   play_sound(99,20);
   while((TCCR1A && _BV(COM1A0))){
     ;;
   }
   play_sound(74,20);
   while((TCCR1A && _BV(COM1A0))){
     ;;
   }
  }
}
/** @}*/
