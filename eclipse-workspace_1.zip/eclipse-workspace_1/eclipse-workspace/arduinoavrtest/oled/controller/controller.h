/*!
 * @file controller.h
 *
 *  Created on: 31.03.2020
 *      Author: V.Weiss, M.Klingler, D.Schmidt
 */

#ifndef CONTROLLER_CONTROLLER_H_
#define CONTROLLER_CONTROLLER_H_

#include <stdbool.h>

void setup_buttons(void);
bool ControllerPressed(uint8_t button);

/*Function prototypes*/
void EncoderSetup(void);
void GetEncoderStatus(uint8_t init);
int8_t GetEncoderL(void);
int8_t GetEncoderR(void);

void AdcSetup(void);
uint16_t GetAdcJSTICK_1(void);
uint16_t GetAdcJSTICK_2(void);


void setup_timer0(void);
uint16_t get_systick(void);
void setup_sound(void);
void play_sound(uint8_t tone, uint16_t length);
void play_melody(void);

#endif /* CONTROLLER_CONTROLLER_H_ */
