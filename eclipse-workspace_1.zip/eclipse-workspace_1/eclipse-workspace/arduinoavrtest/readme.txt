add username to group dialout:
sudo usermod -aG dialout username

install packages (ubuntu)
sudo apt-get install gcc-avr avr* build-essentia make

make clean - Projekt säubern
make all - Projekt übersetzen
make program - Projekt auf Arduino spielen

Makefile
# MCU name
MCU = atmega32u4 #cpu typ Arduino Micro
MCU = atmega328p #cpu typ Arduino nano

F_CPU = 16000000 #cpu typ Arduino Micro
F_CPU = 8000000 #cpu typ Arduino Nano
