#define F_CPU 16000000UL
#define ADC_SCALER 64

#include <stdbool.h>
#include <stdint.h> 
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "i2clcd.h"
#include "i2cmaster.h"
#include <avr/io.h>
#include "pwm.h"
#include "adc.h"

int main( void )
{
    uint16_t adcval;
    char string1[] = "Hello_World!!";

    ADC_Init();
	
    i2c_init();
	lcd_init();
    lcd_light(true);
	lcd_print(string1);
    lcd_command(LCD_DISPLAYON | LCD_CURSORON | LCD_BLINKINGON);
    
    //Externer Quarz als Taktgeber verwenden
    switch_clock_rc_to_extern();
    //Clockdiv auf 0 stellen
    set_clockdiv(0);
    //JTAG deaktivieren
    jtag_deaktivieren();
    //PWM Ausgänge definieren
    DDRB |= (1<<DDB6);
    //Timer1 Initialisieren
    timer1_init();
    //50% PWM für LED0,LED1,LED2 einstellen
    LED0 = 32768/2;

    _delay_ms(1000);
    
    while( 1 ) {
        
        if(1){
        
		} else {  
			adcval = ADC_Read(0);
			sprintf(string1, "ADCVAL: %i", adcval);
			_delay_ms(200);
			lcd_command(LCD_CLEAR);
			_delay_ms(10);
        
			lcd_print(string1);
			_delay_ms(10);
			lcd_nextline();
			_delay_ms(10);
        
			LED1 = (adcval*ADC_SCALER);
			sprintf(string1, "PWM: %u%%", (adcval*10 / 102));
			_delay_ms(10);
			lcd_print(string1);
			_delay_ms(10);
		}
	}
}
