#define F_CPU 16000000UL
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "i2clcd.h"
#include "i2cmaster.h"
#include "rtc.h"


const char string_flash[] PROGMEM = "Hello Flash!";

int main(void)
{
	char string1[40];
    rtc_t rtc;

	i2c_init();
	
	lcd_init();
    lcd_light(true);
	lcd_print(string1);
	lcd_nextline();
    lcd_print_P(PSTR("I2CLCD lala"));

    /*Connect SCL->PC0, SDA->PC1*/    
    RTC_Init();
    rtc.hour = 0x10; //  10:40:20 am
    rtc.min =  0x40;
    rtc.sec =  0x00;

    rtc.date = 0x01; //1st Jan 2016
    rtc.month = 0x01;
    rtc.year = 0x16;
    rtc.weekDay = 5; // Friday: 5th day of week considering monday as first day.
    /*##### Set the time and Date only once. Once the Time and Date is set, comment these lines
         and reflash the code. Else the time will be set every time the controller is reset*/
    RTC_SetDateTime(&rtc);  //  10:40:20 am, 1st Jan 2016
    /* Display the Time and Date continuously */
    
    
    // always set all three parameters  (ON/OFF) when using this command
	lcd_command(LCD_DISPLAYON | LCD_CURSORON | LCD_BLINKINGON);
    _delay_ms(1000);
    lcd_command(LCD_CLEAR);
    _delay_ms(2);
	
    while (1) {
        RTC_GetDateTime(&rtc);
        
        lcd_command(LCD_CLEAR);
        _delay_ms(2);
        
        sprintf(string1,"Time:%2x:%2x:%2x",(uint16_t)rtc.hour,(uint16_t)rtc.min,(uint16_t)rtc.sec);
        lcd_print(string1);
        _delay_ms(2);
        lcd_nextline();
        _delay_ms(2);
        sprintf(string1,"Date:%2x/%2x/%2x",(uint16_t)rtc.date,(uint16_t)rtc.month,(uint16_t)rtc.year);
        lcd_print(string1);
        _delay_ms(1000);

        
    
    }
}
