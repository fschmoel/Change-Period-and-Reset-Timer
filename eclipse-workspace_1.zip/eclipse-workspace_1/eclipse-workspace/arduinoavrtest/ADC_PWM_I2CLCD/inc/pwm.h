 
#include <avr/io.h>

#define LED0 OCR1A
#define LED1 OCR1B
#define LED2 OCR1C

//Funktionen definieren
void timer1_init(void);
void switch_clock_rc_to_extern(void);
void jtag_deaktivieren(void);
void set_clockdiv(uint8_t div);








