var searchData=
[
  ['pin_20assignment',['PIN ASSIGNMENT',['../group___p_i_n___a_s_s_i_g_n_m_e_n_t.html',1,'']]]
];
