var searchData=
[
  ['defined_20bits',['DEFINED BITS',['../group___d_e_f_i_n_e_d___b_i_t_s.html',1,'']]],
  ['defined_20commands',['DEFINED COMMANDS',['../group___d_e_f_i_n_e_d___c_o_m_m_a_n_d_s.html',1,'']]],
  ['defined_20read_20modes',['DEFINED READ MODES',['../group___d_e_f_i_n_e_d___r_e_a_d___m_o_d_e_s.html',1,'']]],
  ['display_20configuration',['DISPLAY CONFIGURATION',['../group___d_i_s_p_l_a_y___c_o_n_f_i_g_u_r_a_t_i_o_n.html',1,'']]]
];
