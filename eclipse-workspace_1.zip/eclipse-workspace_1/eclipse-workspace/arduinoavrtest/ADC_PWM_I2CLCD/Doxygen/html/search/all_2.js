var searchData=
[
  ['gnu_20lesser_20general_20public_20license',['GNU Lesser General Public License',['../_l_i_c_e_n_s_e.html',1,'index']]]
];
