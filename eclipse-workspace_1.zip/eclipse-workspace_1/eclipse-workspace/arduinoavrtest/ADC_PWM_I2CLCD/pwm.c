#include <avr/io.h>

 void timer1_init(void){
//Modus und Vorteiler wählen (Phase Correct PWM und Vorteiler 1)
TCCR1A |= (1<<COM1A1)|(1<<COM1B1)|(1<<COM1C1)|(1<<WGM11);
TCCR1B |= (1<<WGM13)|(1<<CS10);
//Auflösung 16-Bit
ICR1 |= 0xFFFF;
}


//Wechsel zur externen Clock/Crystal
void switch_clock_rc_to_extern(void){
  if(UDINT & (1<<WAKEUPI))
  {
    UDINT &= ~(1<<WAKEUPI);
    CLKSEL0 |= (1<<EXTE);
    while(!(CLKSTA & (1<<EXTON)));
    CLKSEL0 |= (1<<CLKS);
    PLLCSR |= (1<<PLLE);
    CLKSEL0 &= ~(1<<RCE);
    while(!(PLLCSR & (1<<PLOCK)));
    USBCON &= ~(1<<FRZCLK);
  }
}


//JTAG deaktivieren
void jtag_deaktivieren(void){
MCUCR |= (1<<JTD);
MCUCR |= (1<<JTD);
}


//div = 0x00 (div1),div = 0x01(div2),div = 0x02(div4),div = 0x03(div8);
//div = 0x04 (div16),div = 0x05(div32),div = 0x06(div64),div = 0x07(div128)
//div = 0x08 (div256)
void set_clockdiv(uint8_t div){
// Zunächst muss Clock Prescaler Change Enable gesetzt werden
CLKPR = 0x80; 
//Anschließend wird 4x das Register CLKPR gelöscht und damit auf Clock Division Faktor 1 gestellt
CLKPR = div; 
CLKPR = div; 
CLKPR = div; 
CLKPR = div;
}
